-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2022 at 07:59 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `adc_techno`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_Id` text NOT NULL,
  `Customer_Name` text NOT NULL,
  `Mobile` text NOT NULL,
  `Email` text NOT NULL,
  `Category` text NOT NULL,
  `From` text NOT NULL,
  `Comment` text NOT NULL,
  `Feedback` text NOT NULL,
  `followup_date` text NOT NULL,
  `date` text NOT NULL,
  `call_by` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_Id`, `Customer_Name`, `Mobile`, `Email`, `Category`, `From`, `Comment`, `Feedback`, `followup_date`, `date`, `call_by`) VALUES
('0_a', 'a', '', 'a@gmail.com', 'painter', 'justdiall', 'adas', '', '2022-01-12T17:12', '', ''),
('1_my', 'my cust', '', 'a@gmail.com', 'painter', 'facebook', 'as', '', '2022-01-12T20:15', '', ''),
('2_my', 'my cust', 'Call Back', 'a@gmail.com', 'painter', 'facebook', 'as', '', '2022-01-12T20:15', '', ''),
('3_adc', 'adc', '1234567890', 'vidya@adctechno.com', 'gest', 'justdiall', 'as', 'Appointment', '2022-01-12T17:19', '', ''),
('4_adc', 'adc', '1234567890', 'vidya@adctechno.com', 'gest', 'justdiall', 'as', 'Appointment', '2022-01-12T17:19', '', ''),
('5_adc', 'adc', '1234567890', 'vidya@adctechno.com', 'gest', 'justdiall', 'as', 'Appointment', '2022-01-12T17:19', '11/01/22', ''),
('6_abc', 'abc', '1234567890', 'vidya@adctechno.com', 'gest', 'justdiall', 'as', 'Appointment', '2022-01-12T17:19', '11/01/22', ''),
('7_', '', '', '', '', '', '', '', '', '17/01/22', ''),
('7_', '', '', '', '', '', '', '', '', '17/01/22', ''),
('8_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('8_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('9_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('9_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('10_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('11_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('12_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('12_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('13_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('13_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('14_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('15_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('16_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('17_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('18_my', 'my client', '1231231231', 'as@as.as', 'shop', 'as', 'as', 'Not Interested', '', '17/01/22', ''),
('19_as', 'as', '1231231231', 'as@asa.as', 'shop', 'whastaspp', 'as', 'Appointment', '', '17/01/22', ''),
('20_my', 'my client', '1231231231', 'as', 'my ', 'q', 'as', 'Appointment', '', '17/01/22', ''),
('21_adc', 'adc', '1231231231', 'as@as.as', 'it', 'facebook', 'it compny call to....', 'Ringing', '', '17/01/22', ''),
('22_My', 'My data', '1234567890', '1as', 'as', 'as', 'as', 'Appointment', '', '17/01/22', '');

-- --------------------------------------------------------

--
-- Table structure for table `daily_count`
--

CREATE TABLE `daily_count` (
  `name` text NOT NULL,
  `count` int(11) NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `daily_count`
--

INSERT INTO `daily_count` (`name`, `count`, `date`) VALUES
('Sainath', 96, '17/01/22'),
('Prasant', 100, '16/1/2022'),
('Sonali', 100, '16/1/2022');

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE `employee_details` (
  `Employee_ID` text NOT NULL,
  `Employee_Name` text NOT NULL,
  `Bank_Details` text NOT NULL,
  `IFSC_Code` text NOT NULL,
  `designation` text NOT NULL,
  `Aadhar_Name` text NOT NULL,
  `Aadhar_No` text NOT NULL,
  `Dob` text NOT NULL,
  `Doj` text NOT NULL,
  `Email_Id` text NOT NULL,
  `Pan_No` text NOT NULL,
  `Mobile_No` text NOT NULL,
  `Emergency_Mob_No` text NOT NULL,
  `Gender` text NOT NULL,
  `Blood_group` text NOT NULL,
  `Employee_Address` text NOT NULL,
  `R_date` text NOT NULL,
  `Password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`Employee_ID`, `Employee_Name`, `Bank_Details`, `IFSC_Code`, `designation`, `Aadhar_Name`, `Aadhar_No`, `Dob`, `Doj`, `Email_Id`, `Pan_No`, `Mobile_No`, `Emergency_Mob_No`, `Gender`, `Blood_group`, `Employee_Address`, `R_date`, `Password`) VALUES
('0_vidya', 'vidya', 'union bank', '123', '', 'as', '12', 'adc', 'adc', 'enquiry@yashenviro.in', 'asd', '1231231231', '1231231231', 'female', 'Follow Up', 'asd', '16/01/22', ''),
('1_my', 'my emp', 'as', 'as', '', 'as', '12', 'adc', 'adc', 'as@as.as', '1212', '1231231231', '1231231231', 'male', 'Ringing', 'as', '17/01/22', 'adctechno'),
('2_vidya', 'vidya', 'unian', '12', '', 'as', '12', 'adc', 'adc', 'as@as.as', '1212', '1231231231', '1231231231', 'female', 'Cold', '12', '17/01/22', 'vidya@1234'),
('3_new', 'new employee', 'asa', '123', 'sr Software', 'as', '12', '2022-01-18', '2022-01-18', 'enquiry@yashenviro.in', '1', '1231231231', '1231231231', 'female', 'select', '12', '18/01/22', 'vidya@1234'),
('4_new', 'new employee', 'asa', '123', 'sr Software', 'as', '12', '2022-01-18', '2022-01-18', 'enquiry@yashenviro.in', '1', '1231231231', '1231231231', 'female', 'select', '12', '18/01/22', 'vidya@1234'),
('5_new', 'new employee', 'asa', '123', 'sr Software', 'as', '12', '2022-01-18', '2022-01-18', 'enquiry@yashenviro.in', '1', '1231231231', '1231231231', 'female', 'select', '12', '18/01/22', 'vidya@1234');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `id` text NOT NULL,
  `Expenses` text NOT NULL,
  `quantity` text NOT NULL,
  `price` text NOT NULL,
  `comment` text NOT NULL,
  `date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`id`, `Expenses`, `quantity`, `price`, `comment`, `date`) VALUES
('0', 'Tea', '6', '30', '6tea', ''),
('1', 'Stationary', '12', '120', 'pen', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
