
<?php
  
     include "config.php";


 
    
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
        $UserName = $_REQUEST['uname'];
        $Password = $_REQUEST['password'];
        $Name = $_REQUEST['name'];
        $branch = $_REQUEST['branch'];


        echo"UserName".$UserName;
        echo"Password".$Password;
        echo"Name".$Name;
        echo"branch".$branch;   
        $id=0;

    
        // Performing insert query execution
        // here our table name is college
        $sql1 = "INSERT INTO login VALUES ('$UserName','$Password','$Name','$id','$branch')";
          
        if(mysqli_query($conn, $sql1)){
              echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
         echo "<script>window.close();</script>"; 
  echo '<script>window.location.href = "superdashboard.php";</script>';
           

        
              //  echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
        
//echo '<script>window.location.href = "index.php";</script>';
           
        } else{
            echo "ERROR: Hush! Sorry $sql1. " 
                . mysqli_error($conn);
        }
       
    ?>
