<?php
  
        include "config.php";
         
        $User_Name11 = $_REQUEST['uname'];
       
        $Password = $_REQUEST['password'];
       $name="";
		
          $flag=0;
        // Performing insert query execution
        // here our table name is college
        $sql1 = "select * from login";
          $result=mysqli_query($conn,$sql1);
		   while($row = mysqli_fetch_assoc($result))
		   {
			   
			   $name=$row['Name'];
				if($row['UserName']==$User_Name11 && $row['Password']==$Password)
				{
					 echo "Enter in while if";
					if($row['UserName']=='superadmin@admin.com')
					{
						$flag=2;
						session_start();
					 $_SESSION['name'] = $name;
					echo '<script>window.location.href = "superdashboard.php";</script>';
					}
					else
					{
						$flag=1;
						session_start();
					 $_SESSION['name'] = $name;
					echo '<script>window.location.href = "dashboard.php";</script>';
					}
				
				}
				echo $flag;	 
				
				
		   }
		  if($flag==0)
		  {
			 echo "<script type='text/javascript'>alert('Enter Correct User Name And Passwrod!')</script>";  
			 //echo '<script>window.location.href = "Hrlogin.php";</script>';
		  }
      /*  if(mysqli_query($conn, $sql))
		{
         
		 echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
         echo "<script>window.close();</script>"; 
  
           
        } 
		else
		{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        */
        
        ?>