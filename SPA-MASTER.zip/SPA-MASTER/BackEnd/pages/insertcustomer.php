 <!DOCTYPE html>
<html>
<head>
    <title> therapist Page</title>
</head>
<body>
    <center>
<?php


$servername = "localhost";
$username = "root";
$password = "root";
$database = "Spa";
// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
  die("login failed: " . $conn->connect_error);
}
//echo "login successfully";


        // Taking all 5 values from the form data(input)
        $name =  $_REQUEST['name'];
        $mobile = $_REQUEST['mobile'];
       
        $email = $_REQUEST['email'];
        $address = $_REQUEST['address'];
        $dob = $_REQUEST['dob']; 
        $branch = $_REQUEST['branch'];   
        $date=date('d/m/y');


        echo"name".$name;
        echo"mobile".$mobile;
        echo"email".$email;
        echo"address".$address;
        echo"dob".$dob;
      echo"branch".$branch;
        echo"date".$date;
        $id=0;



        // Performing insert query execution
        // here our table name is college
		//add call by details
        $sql1 = "INSERT INTO therapisttb VALUES ('$id','$name','$mobile','$email','$address','$dob','$branch','$date')";

        if(mysqli_query($conn, $sql1)){
              echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
         echo "<script>window.close();</script>"; 
  echo '<script>window.location.href = "dashboard.php";</script>';
           

        
              //  echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
        
//echo '<script>window.location.href = "index.php";</script>';
           
        } else{
            echo "ERROR: Hush! Sorry $sql1. " 
                . mysqli_error($conn);
        }
       
    ?>
</center>
</body>
</html>




