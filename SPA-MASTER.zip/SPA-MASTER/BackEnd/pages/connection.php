<?php
include "config.php";
If(isset($_POST['but_submit'])){
	$uname = mysqli_real_escape_string($con,$_POST['txt_uname']);
	$password = mysqli_Real_escape_string(n,$_POST['txt_pwd']);
	if($uname !="" && $password!=""){

	$sql_query = "select count(*) as cntUser from login where username="'.$uname.'" and password="'.$password.'"";
	$result = mysqli_query($con,$sql_query);
	$row = mysqli_fetch_array($result);
	
	$count = $row['cntUser'];
	if($count > 0){
	$_SESSION['uname'] = $uname;
	header('Location:dashboard.php');
	}else{
	echo "Invalid username and password";
   }

  }

}
?>

