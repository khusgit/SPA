<?php
  
        include "config.php";
          $sql = "SELECT Employee_Id from employee_details";
		  $result=mysqli_query($conn,$sql);
		  //$row=mys($result);
		   $employee =  $_REQUEST['ename'];
		  $id="0";
		  if(mysqli_num_rows($result) == 0)
		  {
			  $nameid=explode(" ",$employee);
			  $id=$id."_".$nameid[0];
			  echo "id is ".$id;
		  }
		  else
		  {
			  while($row = mysqli_fetch_assoc($result))
			  {
			  $id=$row["Employee_Id"];
			  }
			  /*id concat*/
			 $pieces = explode("_", $id);
			$nameid=explode(" ",$employee);
			$pieces[0]=intval($pieces[0])+1;
			$id=$pieces[0]."_".$nameid[0];
			         echo "Id is ".$id;
			     }
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
        $Employee_Name =  $_REQUEST['ename'];
        $Bank_Details = $_REQUEST['bdetails'];
       
        $IFSC_Code= $_REQUEST['ifsccode'];
        $Aadhar_Name = $_REQUEST['adharname'];
        $Aadhar_No = $_REQUEST['aadharno'];
        $Dob = $_REQUEST['dob'];
        $Doj = $_REQUEST['doj'];
	  // $Dob="adc";
	  // $Doj="adc";
       $Email_Id = $_REQUEST['email'];
		$Pan_No = $_REQUEST['panno'];
        $Mobile_No = $_REQUEST['mobile']; 
        $Emergency_Mob_No = $_REQUEST['mobileno']; 
        $Gender = $_REQUEST['gender'];
        $Blood_Gr= $_REQUEST['bloodgr'];
        $Employee_Address=$_REQUEST['address'];
		$date=date("d/m/y");
		$password=$_REQUEST['password'];
		$designation=$_REQUEST['designation'];
        // Performing insert query execution
        // here our table name is college
        $sql1 = "INSERT INTO employee_details  VALUES ('$id','$Employee_Name','$Bank_Details','$IFSC_Code','$designation','$Aadhar_Name','$Aadhar_No','$Dob','$Doj','$Email_Id','$Pan_No','$Mobile_No','$Emergency_Mob_No','$Gender','$Blood_Gr','$Employee_Address','$date','$password')";
          
        if(mysqli_query($conn, $sql1)){
           /* echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
         //code write for page jump on add employee*/
  echo '<script>window.location.href = "dashboard.php";</script>';
           
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        
        
        ?>