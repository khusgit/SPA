<?php

     include 'config.php';

        // Taking all 5 values from the form data(input)
        $UserName = $_REQUEST['uname'];
        $Password = $_REQUEST['password'];
        $newpassword = $_REQUEST['newpassword'];
        $confirmnewpassword = $_REQUEST['confirmnewpassword'];

   ?>
