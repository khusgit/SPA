<?php
  
        include "config.php";
        
			/* $result = $conn->query($sql);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["firstname"]. " " . $row["lastname"]. "<br>";
  }
} else {
  echo "0 results";
}*/  
        // Taking all 5 values from the form data(input)
        $Daily_Expenses =  $_REQUEST['dexpenses'];
        $Quantity = $_REQUEST['quantity'];
       
        $Price= $_REQUEST['price'];
        $Comment = $_REQUEST['comment'];
       $Branch = $_REQUEST['branch']; 
        $Date = $_REQUEST['date1'];
		$date1=date('d/m/y');
       $id=0;
        
        // Performing insert query execution
        // here our table name is college
        $sql = "INSERT INTO expensetb VALUES ('$id','$Daily_Expenses','$Quantity','$Price','$Comment','$Branch','$Date')";
          
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully." 
                . " Please browse your localhost php my admin" 
                . " to view the updated data</h3>";
                echo "<script type='text/javascript'>alert('submitted successfully!')</script>";
         echo "<script>window.close();</script>"; 
  echo '<script>window.location.href = "dashboard.php";</script>';
           
        } else{
            echo "ERROR: Hush! Sorry $sql. " 
                . mysqli_error($conn);
        }
          
        
        
        ?>