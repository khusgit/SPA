/*===== FOCUS =====*/
const inputs = document.querySelectorAll(".form__input")

/*=== Add focus ===*/
function addfocus() {
    let parent = this.parentNode.parentNode
    parent.classList.add("focus")
}

/*=== Remove focus ===*/
function remfocus() {
    let parent = this.parentNode.parentNode
    if (this.value == "") {
        parent.classList.remove("focus")
    }
}

/*=== To call function===*/
inputs.forEach(input => {
    input.addEventListener("focus", addfocus)
    input.addEventListener("blur", remfocus)
})





//form validation function AADHAR() {
function AADHAR() {
    var aadhar = document.getElementById("textaadhar").value;
    var adharcardTwelveDigit = /^[01]\d{3}[\s-]?\d{4}[\s-]?\d{4}$/;
    var adharSixteenDigit = /^\d{16}$/;
    if (aadhar != '') {
        if (aadhar.match(adharcardTwelveDigit)) {
            return true;
        }
        // else if (aadhar.match(adharSixteenDigit)) {
        //     return true;
        // }
        else {
            alert("Enter valid Aadhar Number");
            return false;
        }
    }
}

function IFSC() {
    var aadhar = document.getElementById("textIFSC").value;
    var adharcardTwelveDigit = /[A-Z|a-z]{4}[0][a-zA-Z0-9]{6}$/;
    if (aadhar != '') {
        if (aadhar.match(adharcardTwelveDigit)) {
            return true;
        } else {
            alert("Enter valid IFSC Number");
            return false;
        }
    }
}

function PANCARD() {
    var aadhar = document.getElementById("textPanNo").value;
    var adharcardTwelveDigit = /^([a-zA-Z]{5})(\d{4})([a-zA-Z]{1})$/;
    if (aadhar != '') {
        if (aadhar.match(adharcardTwelveDigit)) {
            return true;
        } else {
            alert("Enter valid PAN Number");
            return false;
        }
    }
}